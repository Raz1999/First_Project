from games.cards.Player import Player
from games.cards.DeckOfCards import DeckOfCards

class CardGame():
    def __init__(self, name1, name2, num_cards = 10):
        self.num_cards=num_cards
        self.player1 = Player(name1, num_cards)
        self.player2 = Player(name2, num_cards)
        self.game_deck = DeckOfCards()
        self.new_game()

    def new_game(self):
        if len(self.game_deck)==52:
            self.game_deck.shuffle_deck()
            for i in range(self.num_cards):
                r_card=self.game_deck.deal_one()
                self.player1.set_hand(r_card)

            for i in range(self.num_cards):
                r2_card=self.game_deck.deal_one()
                self.player2.set_hand(r2_card)
        else:
            print("Error")

    def get_winner(self):
        if self.player1.len_pack<self.player2.len_pack:
            return self.player1
        elif self.player1.len_pack>self.player2.len_pack:
            return self.player2
        elif self.player1.len_pack==self.player2.len_pack:
            return None



