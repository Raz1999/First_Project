from games.cards.Card import Card
from games.cards.DeckOfCards import DeckOfCards
from games.cards.Player import Player

deck1=DeckOfCards()
deck1.show()

